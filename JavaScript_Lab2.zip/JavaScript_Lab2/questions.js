// 1. Какие методы массивов можно использовать для обработки объектов в JavaScript?

// Примеры методов массивов для обработки объектов:
const transactions = [
    {
        transaction_id: "1",
        transaction_date: "2024-02-10",
        transaction_amount: 120,
        transaction_type: "debit",
        transaction_description: "Покупка в магазине",
        merchant_name: "Amazon",
        card_type: "debit"
    },
    {
        transaction_id: "2",
        transaction_date: "2024-02-15",
        transaction_amount: 200,
        transaction_type: "credit",
        transaction_description: "Оплата услуг",
        merchant_name: "Netflix",
        card_type: "credit"
    }
];

// map(): Преобразует каждый элемент массива.
const descriptions = transactions.map(t => t.transaction_description);
console.log("Описания транзакций:", descriptions);

// filter(): Фильтрует элементы массива по условию.
const debitTransactions = transactions.filter(t => t.transaction_type === "debit");
console.log("Дебетовые транзакции:", debitTransactions);

// reduce(): Агрегирует элементы массива в одно значение.
const totalAmount = transactions.reduce((sum, t) => sum + t.transaction_amount, 0);
console.log("Общая сумма транзакций:", totalAmount);

// forEach(): Выполняет функцию для каждого элемента массива.
transactions.forEach(t => console.log("Транзакция:", t.transaction_description));

// find(): Находит первый элемент, удовлетворяющий условию.
const transaction = transactions.find(t => t.transaction_id === "1");
console.log("Транзакция с ID 1:", transaction);

// some(): Проверяет, удовлетворяет ли хотя бы один элемент условию.
const hasDebit = transactions.some(t => t.transaction_type === "debit");
console.log("Есть ли дебетовые транзакции:", hasDebit);

// every(): Проверяет, удовлетворяют ли все элементы условию.
const allDebit = transactions.every(t => t.transaction_type === "debit");
console.log("Все ли транзакции дебетовые:", allDebit);

// sort(): Сортирует элементы массива.
const sortedTransactions = transactions.sort((a, b) => a.transaction_amount - b.transaction_amount);
console.log("Отсортированные транзакции:", sortedTransactions);

// slice(): Возвращает часть массива.
const firstTwoTransactions = transactions.slice(0, 2);
console.log("Первые две транзакции:", firstTwoTransactions);

// concat(): Объединяет массивы.
const additionalTransactions = [
    {
        transaction_id: "3",
        transaction_date: "2024-02-20",
        transaction_amount: 50,
        transaction_type: "debit",
        transaction_description: "Покупка в магазине",
        merchant_name: "eBay",
        card_type: "debit"
    }
];
const newTransactions = transactions.concat(additionalTransactions);
console.log("Объединенные транзакции:", newTransactions);

// 2. Как сравнивать даты в строковом формате в JavaScript?

// Пример сравнения дат в строковом формате:
const date1 = "2024-02-10";
const date2 = "2024-02-15";

if (date1 < date2) {
    console.log("date1 раньше date2");
} else if (date1 > date2) {
    console.log("date1 позже date2");
} else {
    console.log("Даты равны");
}

// Если даты в другом формате, преобразуйте их в объекты Date:
const dateObj1 = new Date("2024-02-10");
const dateObj2 = new Date("2024-02-15");

if (dateObj1 < dateObj2) {
    console.log("dateObj1 раньше dateObj2");
}

// 3. В чем разница между map(), filter() и reduce() при работе с массивами объектов?

// Примеры использования map(), filter() и reduce():

// map(): Преобразует каждый элемент массива.
const amounts = transactions.map(t => t.transaction_amount);
console.log("Суммы транзакций:", amounts);

// filter(): Фильтрует элементы массива по условию.
const creditTransactions = transactions.filter(t => t.transaction_type === "credit");
console.log("Кредитовые транзакции:", creditTransactions);

// reduce(): Агрегирует элементы массива в одно значение.
const totalDebitAmount = transactions
    .filter(t => t.transaction_type === "debit")
    .reduce((sum, t) => sum + t.transaction_amount, 0);
console.log("Общая сумма дебетовых транзакций:", totalDebitAmount);

// Разница:
// - map() возвращает новый массив той же длины.
// - filter() возвращает новый массив, отфильтрованный по условию.
// - reduce() возвращает одно значение (результат агрегации).